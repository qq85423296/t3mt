# -*- coding: utf-8 -*-
"""
影视下载API
"""
from flask import Blueprint, request, jsonify
from services.mango_service import mango_service
from models.video_task import VideoTask
from utils.logger import logger
from utils.feature_gate import check_video_task_limit, check_parse_limit, check_quality_limit

video_bp = Blueprint('video', __name__, url_prefix='/api/video')


@video_bp.route('/read-website', methods=['POST'])
@check_parse_limit()
def read_website():
    """读取官网信息"""
    try:
        from services.video_parse_service import video_parse_service
        
        data = request.get_json()
        url = data.get('url', '').strip()
        platform = data.get('platform', '').strip()  # 可选的平台参数
        
        if not url:
            return jsonify({'code': 400, 'message': '请输入官网地址'})
        
        # 使用video_parse_service统一处理，支持自动识别平台
        result = video_parse_service.read_website(url, platform if platform else None)
        
        if result.get('success'):
            return jsonify({
                'code': 200,
                'message': '读取成功',
                'data': {
                    'video_info': result['video_info'],
                    'episodes': result['episodes'],
                    'total_episodes': result['total_episodes'],
                    'platform': result.get('platform', 'mango')  # 返回识别的平台
                }
            })
        else:
            return jsonify({
                'code': 500,
                'message': result.get('error', '读取失败')
            })
            
    except Exception as e:
        return jsonify({'code': 500, 'message': f'读取失败: {str(e)}'})


@video_bp.route('/task', methods=['POST'])
@check_video_task_limit()
def create_task():
    """创建影视下载任务"""
    try:
        data = request.get_json()
        
        # 验证必填字段
        required_fields = ['name', 'website_url', 'save_directory', 'cron_expression']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'code': 400, 'message': f'缺少必填字段: {field}'})
        
        # 获取平台参数，如果没有则自动识别
        platform = data.get('platform', '')
        if not platform:
            from services.video_parse_service import video_parse_service
            platform = video_parse_service.detect_platform(data['website_url'])
        
        # 创建任务
        task_id = VideoTask.create(
            name=data['name'],
            website_url=data['website_url'],
            video_id=data.get('video_id', ''),
            clip_id=data.get('clip_id', ''),
            save_directory=data['save_directory'],
            cron_expression=data['cron_expression'],
            episodes=data.get('episodes', []),
            video_info=data.get('video_info', {}),
            create_subfolder=data.get('create_subfolder', 0),
            selected_episodes=data.get('selected_episodes', []),
            platform=platform,
            video_type=data.get('video_type', '电视剧')
        )
        
        return jsonify({
            'code': 200,
            'message': '任务创建成功',
            'data': {'id': task_id}
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'创建任务失败: {str(e)}'})


@video_bp.route('/task', methods=['GET'])
def get_task_list():
    """获取任务列表"""
    try:
        tasks = VideoTask.get_all()
        
        task_list = []
        for task in tasks:
            task_dict = task.to_dict()
            task_dict['total_episodes'] = len(task.episodes) if task.episodes else 0
            task_list.append(task_dict)
        
        return jsonify({
            'code': 200,
            'message': '获取成功',
            'data': task_list
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'获取任务列表失败: {str(e)}'})


@video_bp.route('/task/<int:task_id>', methods=['GET'])
def get_task(task_id):
    """获取任务详情"""
    try:
        task = VideoTask.get_by_id(task_id)
        if not task:
            return jsonify({'code': 404, 'message': '任务不存在'})
        
        return jsonify({
            'code': 200,
            'message': '获取成功',
            'data': task.to_dict()
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'获取任务详情失败: {str(e)}'})


@video_bp.route('/task/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """更新任务"""
    try:
        task = VideoTask.get_by_id(task_id)
        if not task:
            return jsonify({'code': 404, 'message': '任务不存在'})
        
        data = request.get_json()
        
        # 更新字段
        update_data = {}
        if 'name' in data:
            update_data['name'] = data['name']
        if 'website_url' in data:
            update_data['website_url'] = data['website_url']
        if 'save_directory' in data:
            update_data['save_directory'] = data['save_directory']
        if 'cron_expression' in data:
            update_data['cron_expression'] = data['cron_expression']
        if 'episodes' in data:
            update_data['episodes'] = data['episodes']
        if 'video_info' in data:
            update_data['video_info'] = data['video_info']
        if 'create_subfolder' in data:
            update_data['create_subfolder'] = data['create_subfolder']
        if 'selected_episodes' in data:
            update_data['selected_episodes'] = data['selected_episodes']
        if 'platform' in data:
            update_data['platform'] = data['platform']
        if 'video_type' in data:
            update_data['video_type'] = data['video_type']
        
        VideoTask.update(task_id, **update_data)
        
        return jsonify({
            'code': 200,
            'message': '更新成功'
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'更新任务失败: {str(e)}'})


@video_bp.route('/task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """删除任务"""
    try:
        from database import db
        
        task = VideoTask.get_by_id(task_id)
        if not task:
            return jsonify({'code': 404, 'message': '任务不存在'})
        
        VideoTask.delete(task_id)
        
        # 删除关联的执行历史记录
        try:
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    DELETE FROM task_execution_history 
                    WHERE task_id = ? AND task_type = 'video'
                ''', (task_id,))
                deleted_count = cursor.rowcount
                logger.info(f"删除影视下载任务 {task_id} 的 {deleted_count} 条执行历史记录")
        except Exception as e:
            logger.warning(f"删除执行历史记录失败: {str(e)}")
        
        return jsonify({
            'code': 200,
            'message': '删除成功'
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'删除任务失败: {str(e)}'})


@video_bp.route('/task/<int:task_id>/execute', methods=['POST'])
def execute_task(task_id):
    """执行任务（立即下载）"""
    try:
        from services.video_download_service import video_download_service
        from services.mango_service import mango_service
        from database import db
        from datetime import datetime
        import os
        
        task = VideoTask.get_by_id(task_id)
        if not task:
            return jsonify({'code': 404, 'message': '任务不存在'})
        
        # 检查是否有剧集
        if not task.episodes or len(task.episodes) == 0:
            return jsonify({'code': 400, 'message': '任务没有可下载的剧集'})
        
        # 检查是否从调度服务传入了execution_id（通过请求体）
        data = request.get_json() if request.is_json else {}
        execution_id = data.get('execution_id')
        
        if execution_id:
            # 使用调度服务传入的execution_id，更新状态为running
            history_id = execution_id
            start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE task_execution_history 
                    SET status = 'running', start_time = ?, total_count = ?
                    WHERE id = ?
                ''', (start_time, len(task.episodes), history_id))
        else:
            # 手动执行：删除该任务之前的所有执行记录，确保每个任务只保留最新一次执行记录
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    DELETE FROM task_execution_history 
                    WHERE task_id = ? AND task_type = 'video'
                ''', (task_id,))
            
            # 创建新的执行历史记录
            start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            with db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO task_execution_history 
                    (task_id, task_type, task_name, start_time, status, total_count)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (task_id, 'video', task.name, start_time, 'running', len(task.episodes)))
                history_id = cursor.lastrowid
        
        # 更新任务状态为执行中
        VideoTask.update(task_id, status='downloading', progress=0)
        
        # 异步执行下载（避免阻塞请求）
        import threading
        import json
        
        def download_thread():
            from utils.task_logger import TaskLogger
            
            error_message = None
            
            # 创建日志记录器
            task_logger = TaskLogger()
            
            # 实时更新日志到数据库的函数
            def update_logs_to_db():
                try:
                    with db.get_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute('''
                            UPDATE task_execution_history 
                            SET logs = ?
                            WHERE id = ?
                        ''', (json.dumps(task_logger.get_logs(), ensure_ascii=False), history_id))
                except Exception as e:
                    logger.error(f"更新日志到数据库失败: {str(e)}")
            
            # 设置日志更新回调
            task_logger.update_callback = update_logs_to_db
            
            try:
                task_logger.info("开始执行影视下载任务")
                task_logger.info(f"任务名称: {task.name}")
                
                # 增量更新：重新读取官网获取最新剧集
                task_logger.info("正在检查更新...")
                
                try:
                    from services.video_parse_service import video_parse_service
                    
                    # 获取任务的平台信息
                    platform = task.platform if hasattr(task, 'platform') and task.platform else 'mango'
                    
                    result = video_parse_service.read_website(task.website_url, platform)
                    if result.get('success'):
                        latest_episodes = result['episodes']
                        task_logger.info(f"官网最新剧集数: {len(latest_episodes)}")
                        
                        # 获取用户选择的剧集索引
                        selected_indices = []
                        if hasattr(task, 'selected_episodes') and task.selected_episodes:
                            try:
                                selected_indices = task.selected_episodes if isinstance(task.selected_episodes, list) else []
                                if selected_indices:
                                    task_logger.info(f"用户选择了 {len(selected_indices)} 集进行下载")
                            except Exception as e:
                                logger.error(f"解析selected_episodes失败: {str(e)}")
                        
                        # 根据用户选择筛选剧集
                        if selected_indices:
                            # 用户指定了要下载的剧集，检查哪些已下载
                            actual_save_directory = task.save_directory
                            if task.create_subfolder:
                                actual_save_directory = os.path.join(task.save_directory, task.name)
                            
                            # 检查哪些剧集已经下载
                            downloaded_episode_names = set()
                            if os.path.exists(actual_save_directory):
                                for file in os.listdir(actual_save_directory):
                                    if file.endswith('.mp4'):
                                        # 去掉.mp4后缀
                                        episode_name = file[:-4]
                                        downloaded_episode_names.add(episode_name)
                            
                            task_logger.info(f"已下载剧集数: {len(downloaded_episode_names)}")
                            
                            # 筛选出需要下载的剧集
                            episodes_to_download = []
                            for index in selected_indices:
                                if 0 <= index < len(latest_episodes):
                                    ep = latest_episodes[index]
                                    
                                    # 构建完整的文件名（与下载时一致）
                                    episode_name = ep.get('name', '')
                                    episode_title = ep.get('title', '')
                                    if episode_title:
                                        full_name = f"{episode_name} - {episode_title}"
                                    else:
                                        full_name = episode_name
                                    
                                    # 清理文件名中的非法字符
                                    illegal_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
                                    safe_name = full_name
                                    for char in illegal_chars:
                                        safe_name = safe_name.replace(char, '_')
                                    safe_name = safe_name.strip()
                                    
                                    # 只添加未下载的剧集
                                    if safe_name not in downloaded_episode_names:
                                        episodes_to_download.append(ep)
                            
                            task_logger.info(f"根据用户选择，需要下载 {len(episodes_to_download)} 集（已跳过 {len(selected_indices) - len(episodes_to_download)} 集）")
                        else:
                            # 用户没有指定，使用增量更新逻辑（只下载未下载的）
                            actual_save_directory = task.save_directory
                            if task.create_subfolder:
                                actual_save_directory = os.path.join(task.save_directory, task.name)
                            
                            # 检查哪些剧集已经下载
                            downloaded_episode_names = set()
                            if os.path.exists(actual_save_directory):
                                for file in os.listdir(actual_save_directory):
                                    if file.endswith('.mp4'):
                                        # 去掉.mp4后缀
                                        episode_name = file[:-4]
                                        downloaded_episode_names.add(episode_name)
                            
                            task_logger.info(f"已下载剧集数: {len(downloaded_episode_names)}")
                            
                            # 筛选出需要下载的新剧集
                            episodes_to_download = []
                            for ep in latest_episodes:
                                # 构建完整的文件名（与下载时一致）
                                episode_name = ep.get('name', '')
                                episode_title = ep.get('title', '')
                                if episode_title:
                                    full_name = f"{episode_name} - {episode_title}"
                                else:
                                    full_name = episode_name
                                
                                # 清理文件名中的非法字符（与video_download_service._sanitize_filename逻辑一致）
                                illegal_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
                                safe_name = full_name
                                for char in illegal_chars:
                                    safe_name = safe_name.replace(char, '_')
                                safe_name = safe_name.strip()
                                
                                if safe_name not in downloaded_episode_names:
                                    episodes_to_download.append(ep)
                        
                        if len(episodes_to_download) == 0:
                            task_logger.info("所有剧集均已下载完成，无需下载")
                            task_logger.info("任务执行完成")
                            
                            # 更新任务状态为完成
                            VideoTask.update(task_id, status='completed', progress=100)
                            
                            # 计算执行时长
                            end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            start_dt = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                            end_dt = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                            duration = int((end_dt - start_dt).total_seconds())
                            
                            # 更新执行历史为成功状态
                            with db.get_connection() as conn:
                                cursor = conn.cursor()
                                cursor.execute('''
                                    UPDATE task_execution_history 
                                    SET end_time = ?, duration = ?, status = ?, logs = ?,
                                        success_count = ?, failed_count = ?
                                    WHERE id = ?
                                ''', (end_time, duration, 'success', json.dumps(task_logger.get_logs(), ensure_ascii=False), 
                                      len(latest_episodes), 0, history_id))
                            
                            logger.info(f"影视下载任务 {task_id} 完成：所有剧集均已下载")
                            return
                        
                        task_logger.info(f"发现 {len(episodes_to_download)} 集新内容")
                        task_logger.info("开始下载新增剧集...")
                        
                        # 更新任务的剧集列表（保存最新的完整列表）
                        VideoTask.update(task_id, episodes=latest_episodes, video_info=result['video_info'])
                        
                        # 使用新剧集列表进行下载
                        task.episodes = episodes_to_download
                        
                    else:
                        task_logger.info("无法获取最新剧集，使用已保存的剧集列表")
                except Exception as e:
                    task_logger.info(f"检查更新失败: {str(e)}，使用已保存的剧集列表")
                    
                    # 使用已保存的剧集列表时，也需要检查是否已全部下载
                    actual_save_directory = task.save_directory
                    if task.create_subfolder:
                        actual_save_directory = os.path.join(task.save_directory, task.name)
                    
                    # 检查哪些剧集已经下载
                    downloaded_episode_names = set()
                    if os.path.exists(actual_save_directory):
                        for file in os.listdir(actual_save_directory):
                            if file.endswith('.mp4'):
                                # 去掉.mp4后缀
                                episode_name = file[:-4]
                                downloaded_episode_names.add(episode_name)
                    
                    task_logger.info(f"已下载剧集数: {len(downloaded_episode_names)}")
                    
                    # 筛选出需要下载的剧集
                    episodes_to_download = []
                    for ep in task.episodes:
                        # 构建完整的文件名（与下载时一致）
                        episode_name = ep.get('name', '')
                        episode_title = ep.get('title', '')
                        if episode_title:
                            full_name = f"{episode_name} - {episode_title}"
                        else:
                            full_name = episode_name
                        
                        # 清理文件名中的非法字符
                        illegal_chars = ['<', '>', ':', '"', '/', '\\', '|', '?', '*']
                        safe_name = full_name
                        for char in illegal_chars:
                            safe_name = safe_name.replace(char, '_')
                        safe_name = safe_name.strip()
                        
                        if safe_name not in downloaded_episode_names:
                            episodes_to_download.append(ep)
                    
                    # 如果所有剧集都已下载，直接返回成功
                    if len(episodes_to_download) == 0:
                        task_logger.info("所有剧集均已下载完成，无需下载")
                        task_logger.info("任务执行完成")
                        
                        # 更新任务状态为完成
                        VideoTask.update(task_id, status='completed', progress=100)
                        
                        # 计算执行时长
                        end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        start_dt = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                        end_dt = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                        duration = int((end_dt - start_dt).total_seconds())
                        
                        # 更新执行历史为成功状态
                        with db.get_connection() as conn:
                            cursor = conn.cursor()
                            cursor.execute('''
                                UPDATE task_execution_history 
                                SET end_time = ?, duration = ?, status = ?, logs = ?,
                                    success_count = ?, failed_count = ?
                                WHERE id = ?
                            ''', (end_time, duration, 'success', json.dumps(task_logger.get_logs(), ensure_ascii=False), 
                                  len(task.episodes), 0, history_id))
                        
                        logger.info(f"影视下载任务 {task_id} 完成：所有剧集均已下载")
                        return
                    
                    # 更新任务的剧集列表为需要下载的剧集
                    task.episodes = episodes_to_download
                
                task_logger.info(f"剧集总数: {len(task.episodes)}")
                
                # 根据create_subfolder决定实际保存路径
                actual_save_directory = task.save_directory
                if task.create_subfolder:
                    actual_save_directory = os.path.join(task.save_directory, task.name)
                    task_logger.info("按名称分类已启用")
                    task_logger.info(f"保存目录: {actual_save_directory}")
                else:
                    task_logger.info(f"保存目录: {actual_save_directory}")
                
                update_logs_to_db()  # 立即更新到数据库
                
                # 进度回调
                def progress_callback(current, total, episode_name, status, 
                                    downloaded=0, total_size=0, percentage=0):
                    # 更新任务进度
                    task_progress = int((current / total) * 100)
                    VideoTask.update(
                        task_id, 
                        progress=task_progress,
                        downloaded_episodes=current - 1 if status in ['success', 'skipped'] else current - 1
                    )
                    
                    # 记录日志
                    if status == 'checking':
                        task_logger.info(f"检查文件: {episode_name}")
                    elif status == 'downloading':
                        if percentage > 0:
                            task_logger.info(f"正在下载: {episode_name} ({percentage:.1f}%)")
                            # 下载进度日志不需要每次都更新到数据库，避免频繁写入
                    elif status == 'success':
                        task_logger.success(f"下载成功: {episode_name}")
                    elif status == 'skipped':
                        task_logger.warning(f"文件已存在，跳过: {episode_name}")
                    elif status == 'failed':
                        task_logger.error(f"下载失败: {episode_name}")
                
                # 执行下载
                result = video_download_service.download_task_episodes(
                    task_id,
                    task.episodes,
                    actual_save_directory,
                    task.name,  # 传入任务名称
                    progress_callback,
                    lambda msg: task_logger.info(msg)
                )
                
                # 更新最终状态
                end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                start_dt = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                end_dt = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                duration = int((end_dt - start_dt).total_seconds())
                
                if result['success']:
                    VideoTask.update(
                        task_id,
                        status='completed',
                        progress=100,
                        downloaded_episodes=result['success_count'] + result.get('skipped_count', 0)
                    )
                    
                    task_logger.info("任务执行完成")
                    task_logger.info(f"新下载: {result['success_count']}, 跳过: {result.get('skipped_count', 0)}, 失败: {result['failed_count']}, 总计: {result['total']}")
                    
                    # 更新执行历史
                    with db.get_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute('''
                            UPDATE task_execution_history 
                            SET end_time = ?, duration = ?, status = ?, 
                                success_count = ?, failed_count = ?, logs = ?
                            WHERE id = ?
                        ''', (end_time, duration, 'success', result['success_count'] + result.get('skipped_count', 0), 
                              result['failed_count'], json.dumps(task_logger.get_logs(), ensure_ascii=False), history_id))
                else:
                    VideoTask.update(
                        task_id,
                        status='failed',
                        downloaded_episodes=result['success_count']
                    )
                    
                    error_message = f"部分下载失败: 成功 {result['success_count']}/{result['total']}"
                    task_logger.info(f"{error_message}")
                    
                    # 更新执行历史
                    with db.get_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute('''
                            UPDATE task_execution_history 
                            SET end_time = ?, duration = ?, status = ?, 
                                success_count = ?, failed_count = ?, logs = ?, error_message = ?
                            WHERE id = ?
                        ''', (end_time, duration, 'failed', result['success_count'], 
                              result['failed_count'], json.dumps(task_logger.get_logs(), ensure_ascii=False), error_message, history_id))
                    
            except Exception as e:
                logger.error(f"下载任务 {task_id} 失败: {str(e)}", exc_info=True)
                VideoTask.update(task_id, status='failed')
                
                error_message = str(e)
                task_logger.info(f"执行异常: {error_message}")
                
                # 更新执行历史
                end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                start_dt = datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S')
                end_dt = datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S')
                duration = int((end_dt - start_dt).total_seconds())
                
                with db.get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute('''
                        UPDATE task_execution_history 
                        SET end_time = ?, duration = ?, status = ?, logs = ?, error_message = ?
                        WHERE id = ?
                    ''', (end_time, duration, 'failed', json.dumps(task_logger.get_logs(), ensure_ascii=False), error_message, history_id))
        
        # 启动下载线程
        thread = threading.Thread(target=download_thread, daemon=True)
        thread.start()
        
        return jsonify({
            'code': 200,
            'message': '任务已开始执行'
        })
        
    except Exception as e:
        logger.error(f"执行任务失败: {str(e)}", exc_info=True)
        return jsonify({'code': 500, 'message': f'执行任务失败: {str(e)}'})


@video_bp.route('/parse-test', methods=['POST'])
def parse_test():
    """测试解析接口"""
    try:
        from services.video_parse_service import video_parse_service
        
        data = request.get_json()
        url = data.get('url', '').strip()
        
        if not url:
            return jsonify({'code': 400, 'message': '请输入测试地址'})
        
        # 调用解析服务
        result = video_parse_service.parse_video_url(url)
        
        if result.get('success'):
            return jsonify({
                'code': 200,
                'message': '解析成功',
                'data': result
            })
        else:
            return jsonify({
                'code': 500,
                'message': result.get('message', '解析失败'),
                'data': result
            })
            
    except Exception as e:
        return jsonify({'code': 500, 'message': f'测试失败: {str(e)}'})


@video_bp.route('/task/<int:task_id>/toggle', methods=['POST'])
def toggle_task(task_id):
    """启用/禁用任务"""
    try:
        task = VideoTask.get_by_id(task_id)
        if not task:
            return jsonify({'code': 404, 'message': '任务不存在'})
        
        # 切换状态
        new_status = 'paused' if task.status == 'running' else 'running'
        VideoTask.update(task_id, status=new_status)
        
        return jsonify({
            'code': 200,
            'message': '状态更新成功',
            'data': {'status': new_status}
        })
        
    except Exception as e:
        return jsonify({'code': 500, 'message': f'更新状态失败: {str(e)}'})
