# -*- coding: utf-8 -*-
"""
任务执行器 - 异步执行下载任务（支持多线程分块下载）
"""
import os
import threading
import requests
import time
from datetime import datetime
from typing import Dict, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from services.quark_service import QuarkService
from services.download_service import DownloadService
from models.account import Account
from models.config import ConfigModel
from utils.logger import logger


class TaskExecutor:
    """任务执行器"""
    
    # 存储正在执行的任务状态
    _running_tasks: Dict[int, Dict] = {}
    _lock = threading.Lock()
    
    @classmethod
    def _get_config(cls, key: str, default):
        """获取配置值"""
        try:
            value = ConfigModel.get_config(key, str(default))
            # 转换为正确的类型
            if isinstance(default, bool):
                # 布尔值判断：支持多种格式
                if isinstance(value, bool):
                    return value
                if isinstance(value, str):
                    return value.lower() in ('true', '1', 'yes', 'on')
                return bool(value)
            elif isinstance(default, int):
                return int(value)
            else:
                return value
        except Exception as e:
            logger.warning(f"获取配置 {key} 失败: {e}，使用默认值: {default}")
            return default
    
    @classmethod
    def stop_task(cls, task_id: int) -> bool:
        """
        停止任务执行
        
        Args:
            task_id: 任务ID
            
        Returns:
            是否成功停止
        """
        with cls._lock:
            if task_id not in cls._running_tasks:
                return False
            
            # 标记任务为已停止
            cls._running_tasks[task_id]['status'] = 'stopped'
            cls._add_log(task_id, '任务已被手动终止', 'warning')
            
            logger.info(f"任务 {task_id} 已标记为停止")
            return True
    
    @classmethod
    def start_task(cls, task_id: int, execution_id: int = None, schedule_period: str = None) -> bool:
        """
        启动任务执行
        
        Args:
            task_id: 任务ID
            execution_id: 执行记录ID（可选，用于调度任务）
            schedule_period: 账期（可选）
            
        Returns:
            是否成功启动
        """
        logger.info(f"[TaskExecutor] start_task 被调用: task_id={task_id}, execution_id={execution_id}, schedule_period={schedule_period}")
        
        with cls._lock:
            # 检查任务是否已在执行
            if task_id in cls._running_tasks:
                logger.warning(f"[TaskExecutor] 任务 {task_id} 已在执行中")
                return False
            
            # 初始化任务状态
            cls._running_tasks[task_id] = {
                'status': 'running',
                'logs': [],
                'progress': 0,
                'current_file': '',
                'downloaded_files': 0,
                'total_files': 0,
                'success_count': 0,
                'fail_count': 0,
                'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'execution_id': execution_id,
                'schedule_period': schedule_period
            }
            logger.info(f"[TaskExecutor] 任务 {task_id} 状态已初始化到 _running_tasks")
        
        # 在新线程中执行任务
        thread = threading.Thread(target=cls._execute_task, args=(task_id,), daemon=True)
        thread.start()
        logger.info(f"[TaskExecutor] 任务 {task_id} 执行线程已启动")
        
        return True
    
    @classmethod
    def get_task_status(cls, task_id: int) -> Dict:
        """获取任务状态"""
        with cls._lock:
            status = cls._running_tasks.get(task_id, None)
            if status:
                logger.debug(f"[TaskExecutor] get_task_status({task_id}): 找到状态, logs数量={len(status.get('logs', []))}")
            else:
                logger.debug(f"[TaskExecutor] get_task_status({task_id}): 未找到状态")
            return status
    
    @classmethod
    def _add_log(cls, task_id: int, message: str, log_type: str = 'info'):
        """添加日志"""
        with cls._lock:
            if task_id in cls._running_tasks:
                cls._running_tasks[task_id]['logs'].append({
                    'message': message,
                    'type': log_type,
                    'timestamp': datetime.now().strftime('%H:%M:%S')
                })
                logger.info(f"[下载任务{task_id}] {message}")
                
                # 同步更新数据库中的日志(如果有execution_id)
                execution_id = cls._running_tasks[task_id].get('execution_id')
                if execution_id:
                    try:
                        from database import get_db
                        import json
                        
                        # 将日志转换为JSON格式保存
                        logs_json = json.dumps(cls._running_tasks[task_id]['logs'], ensure_ascii=False)
                        
                        with get_db() as conn:
                            cursor = conn.cursor()
                            cursor.execute('''
                                UPDATE task_execution_history 
                                SET logs = ?
                                WHERE id = ?
                            ''', (logs_json, execution_id))
                            conn.commit()
                    except Exception as e:
                        logger.error(f"更新执行历史日志失败: {e}")
            else:
                # 任务不在运行列表中，只记录到应用日志
                logger.info(f"[下载任务{task_id}] {message}")
    
    @classmethod
    def _update_progress(cls, task_id: int, **kwargs):
        """更新任务进度"""
        with cls._lock:
            if task_id in cls._running_tasks:
                cls._running_tasks[task_id].update(kwargs)
    
    @classmethod
    def _format_size(cls, size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.2f} {unit}"
            size /= 1024.0
        return f"{size:.2f} PB"
    
    @classmethod
    def _download_chunk(cls, task_id: int, download_url: str, headers: dict, start: int, end: int, 
                       chunk_file: Path, chunk_index: int, total_chunks: int, retry: int = 0) -> Dict:
        """
        下载文件的一个分块
        
        Args:
            task_id: 任务ID
            download_url: 下载链接
            headers: 请求头
            start: 起始字节
            end: 结束字节
            chunk_file: 分块文件保存路径
            chunk_index: 分块索引
            total_chunks: 总分块数
            retry: 当前重试次数
        """
        try:
            chunk_headers = headers.copy()
            chunk_headers['Range'] = f'bytes={start}-{end}'
            
            timeout = cls._get_config('download_timeout', 30)
            
            cls._add_log(task_id, f"      线程 {chunk_index + 1}/{total_chunks} 开始下载 ({cls._format_size(start)}-{cls._format_size(end)})", 'info')
            
            response = requests.get(
                download_url,
                headers=chunk_headers,
                stream=True,
                timeout=timeout,
                verify=False
            )
            
            if response.status_code not in [200, 206]:
                raise Exception(f"状态码: {response.status_code}")
            
            # 写入分块文件
            downloaded = 0
            chunk_size_bytes = end - start + 1
            with open(chunk_file, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
            
            cls._add_log(task_id, f"      线程 {chunk_index + 1}/{total_chunks} 完成 ({cls._format_size(chunk_file.stat().st_size)})", 'success')
            
            return {'success': True, 'size': chunk_file.stat().st_size}
            
        except Exception as e:
            retry_times = cls._get_config('download_retry_count', 3)
            retry_delay = cls._get_config('download_retry_delay', 5)
            
            if retry < retry_times:
                cls._add_log(task_id, f"      线程 {chunk_index + 1}/{total_chunks} 失败，重试 {retry + 1}/{retry_times}", 'warning')
                time.sleep(retry_delay)
                return cls._download_chunk(task_id, download_url, headers, start, end, chunk_file, chunk_index, total_chunks, retry + 1)
            else:
                cls._add_log(task_id, f"      线程 {chunk_index + 1}/{total_chunks} 失败: {str(e)}", 'error')
                return {'success': False, 'message': str(e)}
    
    @classmethod
    def _merge_chunks(cls, target_file: Path, chunk_files: List[Path]) -> bool:
        """合并文件分块"""
        try:
            with open(target_file, 'wb') as target:
                for chunk_file in chunk_files:
                    if not chunk_file.exists():
                        raise Exception(f"分块文件不存在: {chunk_file}")
                    
                    with open(chunk_file, 'rb') as chunk:
                        target.write(chunk.read())
                    
                    chunk_file.unlink()
            
            return True
        except Exception as e:
            logger.error(f"合并文件分块失败: {e}")
            return False
    
    @classmethod
    def _download_file_multithread(cls, task_id: int, file_info: dict, download_url: str, 
                                   headers: dict, local_file_path: str) -> bool:
        """
        多线程分块下载单个文件
        
        Args:
            task_id: 任务ID
            file_info: 文件信息
            download_url: 下载链接
            headers: 请求头
            local_file_path: 本地文件路径
        """
        file_name = file_info['file_name']
        file_size = file_info['size']
        
        target_file = Path(local_file_path)
        
        # 从配置读取参数
        threads_per_file = cls._get_config('download_threads_per_file', 4)
        multithread_chunk_size = cls._get_config('download_multithread_chunk_size', 10) * 1024 * 1024
        
        cls._add_log(task_id, f"🚀 使用多线程下载: {file_name} ({cls._format_size(file_size)})", 'info')
        cls._add_log(task_id, f"   配置: {threads_per_file} 个线程，每块 {cls._format_size(multithread_chunk_size)}", 'info')
        
        try:
            # 计算分块
            num_chunks = (file_size + multithread_chunk_size - 1) // multithread_chunk_size
            chunks = []
            
            for i in range(num_chunks):
                start = i * multithread_chunk_size
                end = min(start + multithread_chunk_size - 1, file_size - 1)
                chunk_file = target_file.with_suffix(f'.part{i}')
                chunks.append({
                    'start': start,
                    'end': end,
                    'file': chunk_file,
                    'index': i
                })
            
            cls._add_log(task_id, f"   分块数量: {num_chunks}", 'info')
            
            # 并行下载所有分块
            start_time = time.time()
            failed_chunks = []
            
            with ThreadPoolExecutor(max_workers=threads_per_file) as executor:
                future_to_chunk = {
                    executor.submit(
                        cls._download_chunk,
                        task_id,
                        download_url,
                        headers,
                        chunk['start'],
                        chunk['end'],
                        chunk['file'],
                        chunk['index'],
                        num_chunks
                    ): chunk
                    for chunk in chunks
                }
                
                for future in as_completed(future_to_chunk):
                    chunk = future_to_chunk[future]
                    try:
                        result = future.result()
                        if not result['success']:
                            failed_chunks.append(chunk['index'])
                    except Exception as e:
                        failed_chunks.append(chunk['index'])
                        logger.error(f"分块 {chunk['index']} 异常: {e}")
            
            # 检查是否有失败的分块
            if failed_chunks:
                for chunk in chunks:
                    if chunk['file'].exists():
                        chunk['file'].unlink()
                cls._add_log(task_id, f"   部分分块下载失败: {failed_chunks}", 'error')
                return False
            
            # 合并分块
            cls._add_log(task_id, f"   合并 {num_chunks} 个分块...", 'info')
            chunk_files = [chunk['file'] for chunk in chunks]
            
            if not cls._merge_chunks(target_file, chunk_files):
                return False
            
            # 验证文件大小
            actual_size = target_file.stat().st_size
            if actual_size != file_size:
                target_file.unlink()
                cls._add_log(task_id, f"   文件大小不匹配: {actual_size}/{file_size}", 'error')
                return False
            
            elapsed_time = time.time() - start_time
            speed = file_size / elapsed_time if elapsed_time > 0 else 0
            
            cls._add_log(task_id, f"✅ 多线程下载完成: {file_name}", 'success')
            cls._add_log(task_id, f"   耗时: {elapsed_time:.1f}秒，平均速度: {cls._format_size(speed)}/s", 'info')
            return True
            
        except Exception as e:
            # 清理分块文件
            for chunk in chunks:
                if chunk['file'].exists():
                    chunk['file'].unlink()
            cls._add_log(task_id, f"多线程下载失败: {file_name} - {str(e)}", 'error')
            return False
    
    @classmethod
    def _download_file_single(cls, task_id: int, file_info: dict, download_url: str, 
                             headers: dict, local_file_path: str) -> bool:
        """
        单线程下载文件
        
        Args:
            task_id: 任务ID
            file_info: 文件信息
            download_url: 下载链接
            headers: 请求头
            local_file_path: 本地文件路径
        """
        file_name = file_info['file_name']
        file_size = file_info['size']
        
        try:
            temp_file_path = local_file_path + '.tmp'
            
            timeout = cls._get_config('download_timeout', 30)
            chunk_size = cls._get_config('download_chunk_size', 2) * 1024 * 1024
            
            response = requests.get(download_url, headers=headers, stream=True, timeout=timeout)
            
            if response.status_code != 200:
                cls._add_log(task_id, f"下载失败，状态码: {response.status_code}", 'error')
                return False
            
            # 分块写入文件
            downloaded_size = 0
            with open(temp_file_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
            
            # 验证文件大小
            if file_size > 0 and downloaded_size != file_size:
                os.remove(temp_file_path)
                cls._add_log(task_id, f"文件大小不匹配: {downloaded_size}/{file_size}", 'error')
                return False
            
            # 重命名临时文件
            if os.path.exists(local_file_path):
                os.remove(local_file_path)
            os.rename(temp_file_path, local_file_path)
            
            cls._add_log(task_id, f"✅ 单线程下载完成: {file_name}", 'success')
            return True
            
        except Exception as e:
            temp_file_path = local_file_path + '.tmp'
            if os.path.exists(temp_file_path):
                try:
                    os.remove(temp_file_path)
                except:
                    pass
            cls._add_log(task_id, f"下载异常: {str(e)}", 'error')
            return False
    
    @classmethod
    def _execute_task(cls, task_id: int):
        """执行下载任务（在后台线程中运行）"""
        execution_id = None
        schedule_period = None
        
        logger.info(f"[TaskExecutor] _execute_task 线程开始执行: task_id={task_id}")
        
        try:
            # 获取任务状态中的execution_id和schedule_period
            with cls._lock:
                if task_id in cls._running_tasks:
                    execution_id = cls._running_tasks[task_id].get('execution_id')
                    schedule_period = cls._running_tasks[task_id].get('schedule_period')
                    logger.info(f"[TaskExecutor] 从_running_tasks获取: execution_id={execution_id}, schedule_period={schedule_period}")
                else:
                    logger.error(f"[TaskExecutor] 任务 {task_id} 不在 _running_tasks 中！")
            
            # 获取任务信息
            logger.info(f"[TaskExecutor] 开始获取任务信息: task_id={task_id}")
            task = DownloadService.get_task_by_id(task_id)
            if not task:
                logger.error(f"[TaskExecutor] 任务 {task_id} 不存在")
                cls._add_log(task_id, '任务不存在', 'error')
                cls._update_progress(task_id, status='failed')
                return
            
            logger.info(f"[TaskExecutor] 任务信息获取成功: {task['name']}")
            
            # 如果没有传入execution_id，先创建执行历史记录
            if not execution_id:
                logger.info(f"[TaskExecutor] 开始创建执行历史记录")
                from database import get_db
                with get_db() as conn:
                    cursor = conn.cursor()
                    
                    # 如果没有账期，生成当前时间的账期
                    if not schedule_period:
                        schedule_period = datetime.now().strftime('%Y%m%d%H')
                    
                    cursor.execute("""
                        INSERT INTO task_execution_history (
                            task_id, task_type, task_name, schedule_period,
                            status, start_time, logs
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (task_id, 'download', task['name'], schedule_period, 
                          'running', datetime.now(), '[]'))
                    conn.commit()
                    execution_id = cursor.lastrowid
                    
                    logger.info(f"[TaskExecutor] 执行历史记录创建成功: execution_id={execution_id}")
                    
                    # 更新任务状态中的execution_id
                    with cls._lock:
                        if task_id in cls._running_tasks:
                            cls._running_tasks[task_id]['execution_id'] = execution_id
                            logger.info(f"[TaskExecutor] execution_id已更新到_running_tasks")
            
            # 开始记录日志
            logger.info(f"[TaskExecutor] 开始记录日志")
            cls._add_log(task_id, '任务已启动，正在初始化...', 'info')
            cls._add_log(task_id, f'执行历史记录ID: {execution_id}', 'info')
            cls._add_log(task_id, f"开始执行任务: {task['name']}", 'info')
            
            # 获取源账号
            account = Account.get_by_id(task['source_account_id'])
            if not account:
                cls._add_log(task_id, '源账号不存在', 'error')
                cls._update_progress(task_id, status='failed')
                return
            
            cls._add_log(task_id, f"使用账号: {account['remark']}", 'info')
            cls._add_log(task_id, f"网盘目录: {task['source_path']}", 'info')
            cls._add_log(task_id, f"本地目录: {task['target_path']}", 'info')
            
            # 初始化夸克服务
            quark = QuarkService(account['cookie'])
            
            # 获取文件列表
            cls._add_log(task_id, '正在获取文件列表...', 'info')
            
            source_path = task['source_path']
            folder_id = '0'
            
            if source_path and source_path != '/':
                path_parts = [p for p in source_path.strip('/').split('/') if p]
                cls._add_log(task_id, f"解析路径: {' -> '.join(path_parts)}", 'info')
                
                current_fid = '0'
                for part in path_parts:
                    result = quark.get_file_list(current_fid, 1, 100)
                    if result.get('code') != 0:
                        cls._add_log(task_id, f"获取目录失败: {result.get('message')}", 'error')
                        cls._update_progress(task_id, status='failed')
                        return
                    
                    files = result.get('data', {}).get('list', [])
                    found = False
                    for f in files:
                        if f.get('dir') and f.get('file_name') == part:
                            current_fid = f.get('fid')
                            found = True
                            break
                    
                    if not found:
                        cls._add_log(task_id, f"未找到目录: {part}", 'error')
                        cls._update_progress(task_id, status='failed')
                        return
                
                folder_id = current_fid
            
            # 递归获取所有文件和文件夹的函数
            def get_all_files_recursive(folder_id, parent_path="", depth=0, max_depth=10):
                """递归获取文件夹中的所有文件，保留层级关系"""
                if depth > max_depth:
                    cls._add_log(task_id, f"达到最大递归深度 {max_depth}，停止递归", 'warning')
                    return []
                
                result = quark.get_file_list(folder_id, 1, 100)
                
                if result.get('code') != 0:
                    cls._add_log(task_id, f"获取文件列表失败: {result.get('message')}", 'error')
                    return []
                
                items = result.get('data', {}).get('list', [])
                all_files = []
                
                for item in items:
                    item_name = item.get('file_name', '')
                    item_path = f"{parent_path}/{item_name}" if parent_path else item_name
                    
                    if item.get('dir'):
                        # 这是一个文件夹
                        cls._add_log(task_id, f"正在扫描文件夹: {item_path}", 'info')
                        
                        # 递归获取子文件夹
                        sub_files = get_all_files_recursive(item.get('fid'), item_path, depth + 1, max_depth)
                        all_files.extend(sub_files)
                    else:
                        # 这是一个文件
                        file_info = {
                            'file': item,
                            'relative_path': parent_path  # 相对于根目录的路径
                        }
                        all_files.append(file_info)
                
                return all_files
            
            # 递归获取所有文件
            cls._add_log(task_id, '开始递归扫描文件...', 'info')
            all_files = get_all_files_recursive(folder_id)
            
            if not all_files:
                cls._add_log(task_id, '未找到任何文件', 'warning')
                cls._update_progress(task_id, status='completed', total_files=0)
                return
            
            cls._add_log(task_id, f"递归扫描完成，共找到 {len(all_files)} 个文件", 'info')
            
            # 应用过滤规则
            filtered_files = all_files
            
            # 过滤扩展名（排除）
            if task.get('filter_extensions'):
                exts = [e.strip() for e in task['filter_extensions'].split(',')]
                # 确保扩展名以点开头
                exts = [ext if ext.startswith('.') else f'.{ext}' for ext in exts]
                filtered_files = [f for f in filtered_files if not any(f['file'].get('file_name', '').endswith(ext) for ext in exts)]
                cls._add_log(task_id, f"排除扩展名 {', '.join(exts)} 后剩余 {len(filtered_files)} 个文件", 'info')
            
            # 过滤扩展名（包含）
            if task.get('include_extensions'):
                exts = [e.strip() for e in task['include_extensions'].split(',')]
                # 确保扩展名以点开头
                exts = [ext if ext.startswith('.') else f'.{ext}' for ext in exts]
                filtered_files = [f for f in filtered_files if any(f['file'].get('file_name', '').endswith(ext) for ext in exts)]
                cls._add_log(task_id, f"仅保留扩展名 {', '.join(exts)} 后剩余 {len(filtered_files)} 个文件", 'info')
            
            if not filtered_files:
                cls._add_log(task_id, '没有需要下载的文件', 'warning')
                cls._update_progress(task_id, status='completed', total_files=0)
                return
            
            cls._update_progress(task_id, total_files=len(filtered_files))
            cls._add_log(task_id, f"准备下载 {len(filtered_files)} 个文件", 'info')
            
            # 确保本地目录存在
            target_path = task['target_path']
            if not os.path.exists(target_path):
                try:
                    os.makedirs(target_path, exist_ok=True)
                    cls._add_log(task_id, f"创建本地目录: {target_path}", 'info')
                except Exception as e:
                    cls._add_log(task_id, f"创建本地目录失败: {str(e)}", 'error')
                    cls._update_progress(task_id, status='failed')
                    return
            
            # 开始下载文件
            success_count = 0
            fail_count = 0
            
            for idx, file_info in enumerate(filtered_files, 1):
                # 检查任务是否被停止
                with cls._lock:
                    if task_id in cls._running_tasks and cls._running_tasks[task_id].get('status') == 'stopped':
                        cls._add_log(task_id, '任务已终止，停止下载', 'warning')
                        break
                
                file = file_info['file']
                relative_path = file_info['relative_path']
                
                file_name = file.get('file_name')
                file_fid = file.get('fid')
                file_size = file.get('size', 0)
                size_mb = file_size / (1024 * 1024)
                
                # 显示文件的完整路径
                display_path = f"{relative_path}/{file_name}" if relative_path else file_name
                
                progress = int((idx - 1) / len(filtered_files) * 100)
                cls._update_progress(
                    task_id,
                    current_file=display_path,
                    downloaded_files=idx - 1,
                    progress=progress
                )
                
                cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 正在下载: {display_path} ({size_mb:.2f} MB)", 'info')
                
                try:
                    # 构建本地文件路径（保持目录结构）
                    if relative_path:
                        local_dir = os.path.join(target_path, relative_path)
                        # 确保子目录存在
                        if not os.path.exists(local_dir):
                            os.makedirs(local_dir, exist_ok=True)
                            cls._add_log(task_id, f"   创建子目录: {relative_path}", 'info')
                        local_file_path = os.path.join(local_dir, file_name)
                    else:
                        local_file_path = os.path.join(target_path, file_name)
                    
                    # 检查文件是否已存在
                    if os.path.exists(local_file_path):
                        local_size = os.path.getsize(local_file_path)
                        if local_size == file_size:
                            cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 文件已存在，跳过", 'info')
                            success_count += 1
                            continue
                        else:
                            cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 文件大小不匹配，重新下载", 'warning')
                    
                    # 获取下载链接
                    download_result, download_cookie = quark.get_download_url([file_fid])
                    
                    if download_result.get('code') != 0:
                        cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 获取下载链接失败", 'error')
                        fail_count += 1
                        continue
                    
                    download_data = download_result.get('data', [])
                    if not download_data:
                        cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 下载链接为空", 'error')
                        fail_count += 1
                        continue
                    
                    download_url = download_data[0].get('download_url')
                    if not download_url:
                        cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 下载链接无效", 'error')
                        fail_count += 1
                        continue
                    
                    # 准备请求头
                    # 从Config获取夸克Referer
                    from config import Config
                    if not Config.QUARK_BASE_URL:
                        raise ValueError("夸克API配置未加载,无法下载文件,请联系管理员")
                    
                    quark_referer = Config.QUARK_BASE_URL.replace('drive-pc', 'pan')
                    
                    download_headers = {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                        'Referer': quark_referer,
                        'Cookie': download_cookie if download_cookie else account['cookie']
                    }
                    
                    # 判断是否使用多线程下载
                    file_info = {'file_name': file_name, 'size': file_size}
                    
                    enable_multithread = cls._get_config('download_enable_multithread', True)
                    multithread_threshold = cls._get_config('download_multithread_threshold', 50) * 1024 * 1024
                    
                    # 调试日志：输出配置值
                    cls._add_log(task_id, f"[调试] 多线程配置: enable={enable_multithread}, threshold={multithread_threshold/(1024*1024):.0f}MB", 'info')
                    
                    # 输出下载策略日志
                    if enable_multithread and file_size >= multithread_threshold:
                        cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 文件大小 {size_mb:.2f}MB >= {multithread_threshold/(1024*1024):.0f}MB，使用多线程下载", 'info')
                        # 大文件使用多线程下载
                        download_success = cls._download_file_multithread(
                            task_id, file_info, download_url, download_headers, local_file_path
                        )
                    else:
                        if not enable_multithread:
                            cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 多线程下载已禁用，使用单线程下载", 'info')
                        else:
                            cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 文件大小 {size_mb:.2f}MB < {multithread_threshold/(1024*1024):.0f}MB，使用单线程下载", 'info')
                        # 小文件使用单线程下载
                        download_success = cls._download_file_single(
                            task_id, file_info, download_url, download_headers, local_file_path
                        )
                    
                    if download_success:
                        success_count += 1
                    else:
                        fail_count += 1
                    
                    # 更新数据库进度
                    DownloadService.update_progress(task_id, progress)
                    
                except Exception as e:
                    cls._add_log(task_id, f"[{idx}/{len(filtered_files)}] 下载异常: {str(e)}", 'error')
                    fail_count += 1
            
            # 更新任务执行时间和进度
            DownloadService.update_execute_time(task_id, last_time=datetime.now())
            DownloadService.update_progress(task_id, 100)
            
            # 更新执行历史记录
            if execution_id:
                import json
                from database import get_db
                with get_db() as conn:
                    cursor = conn.cursor()
                    logs_json = json.dumps(cls._running_tasks[task_id]['logs'], ensure_ascii=False)
                    cursor.execute("""
                        UPDATE task_execution_history 
                        SET status = ?, end_time = ?, logs = ?,
                            success_count = ?, failed_count = ?
                        WHERE id = ?
                    """, ('success', datetime.now(), logs_json, success_count, fail_count, execution_id))
                    conn.commit()
            
            # 更新最终状态
            cls._update_progress(
                task_id,
                status='completed',
                progress=100,
                downloaded_files=len(filtered_files),
                success_count=success_count,
                fail_count=fail_count,
                current_file=''
            )
            
            cls._add_log(task_id, f"\n任务执行完成！", 'success')
            cls._add_log(task_id, f"成功: {success_count} 个，失败: {fail_count} 个", 'info')
            
        except Exception as e:
            cls._add_log(task_id, f"执行异常: {str(e)}", 'error')
            cls._update_progress(task_id, status='failed')
            
            # 更新执行历史记录为失败
            if execution_id:
                import json
                from database import get_db
                with get_db() as conn:
                    cursor = conn.cursor()
                    logs_json = json.dumps(cls._running_tasks.get(task_id, {}).get('logs', []), ensure_ascii=False)
                    cursor.execute("""
                        UPDATE task_execution_history 
                        SET status = ?, end_time = ?, logs = ?, error_message = ?
                        WHERE id = ?
                    """, ('failed', datetime.now(), logs_json, str(e), execution_id))
                    conn.commit()
            
            logger.error(f"执行下载任务异常: {e}", exc_info=True)
    
    @classmethod
    def clear_task(cls, task_id: int):
        """清除任务状态"""
        with cls._lock:
            if task_id in cls._running_tasks:
                del cls._running_tasks[task_id]
